A small utility for processing ECU log files to help tuning for Subaru owners (some tools will work for other cars)

Sorry for the confusing name, it started as mafscaler but then evolved into a bit more than that.

Currently these tools are implemented:

MAF Open Loop Scaling

MAF Closed Loop Scaling

MAF Rescaling

Table Rescaling

Throttle Maps

Load Compensation / Injector Pulse Width Compensation

IAT Compensation

MAF VE Calculation

WOT best VVT

Log Statistics (learning)

Log view, WOT comparison, and map tracing (replay)



WIKI page - https://github.com/vimsh/mafscaling/wiki

Thread on RomRaider - http://www.romraider.com/forum/viewtopic.php?t=10481
