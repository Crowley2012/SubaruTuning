A small utility for processing ECU log files to help tuning for Subaru owners (some tools will work fo rother cars)

Sorry for the confusing name, it started as mafscaler but then evolved into a bit more than that.

Currently these tools are implemented:

MAF CL/OL Scaling

MAF Rescaling

Table Rescaling

Load Compensation / Injector Pulse Width Compensation

IAT Compensation

SD Calculations

WOT best VVT

Log statistics (learning)

Log view, WOT comparison, and map tracing (replay)



WIKI page - https://github.com/vimsh/mafscaling/wiki

Thread on RomRaider - http://www.romraider.com/forum/viewtopic.php?t=10481
